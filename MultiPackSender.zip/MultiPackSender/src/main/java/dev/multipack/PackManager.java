package dev.multipack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

public class PackManager {

    private static final Pattern HEX_PATTERN = Pattern.compile("^[0-9a-f]{40}$");
    // Detect placeholder hashes: the default config ships hashes like
    // "000...0001", "000...0002" etc. Any hash with fewer than 4 non-zero
    // nibbles is almost certainly a placeholder and not a real SHA-1.
    private static final int MIN_NONZERO_NIBBLES = 4;

    private final MultiPackSender plugin;

    // Both fields are volatile: written on main thread by loadPacks(), read on
    // join event / async threads. volatile ensures visibility across threads.
    private volatile List<ResourcePackEntry> packs = Collections.emptyList();
    private volatile int sendDelayTicks = 20;

    public PackManager(MultiPackSender plugin) {
        this.plugin = plugin;
    }

    public boolean loadPacks() {
        List<ResourcePackEntry> newPacks = new ArrayList<>();

        sendDelayTicks = Math.max(0, plugin.getConfig().getInt("send-delay-ticks", 20));

        ConfigurationSection packsSection = plugin.getConfig().getConfigurationSection("resource-packs");
        if (packsSection == null) {
            plugin.getLogger().warning("No 'resource-packs' section found in config.yml!");
            packs = Collections.emptyList();
            return false;
        }

        for (String key : packsSection.getKeys(false)) {
            ConfigurationSection entry = packsSection.getConfigurationSection(key);
            if (entry == null) continue;

            String url   = entry.getString("url",  "").trim();
            String hash  = entry.getString("sha1", "").trim().toLowerCase();
            boolean required = entry.getBoolean("required", true);
            String prompt    = entry.getString("prompt", "");

            if (url.isEmpty()) {
                plugin.getLogger().warning("Pack '" + key + "' has no URL, skipping.");
                continue;
            }
            if (!isValidUrl(url)) {
                plugin.getLogger().warning("Pack '" + key + "' has a malformed URL: " + url + ", skipping.");
                continue;
            }

            if (hash.isEmpty()) {
                plugin.getLogger().warning("Pack '" + key + "' has no SHA-1 hash, skipping.");
                continue;
            }
            if (!HEX_PATTERN.matcher(hash).matches()) {
                plugin.getLogger().warning("Pack '" + key + "' has an invalid SHA-1 hash (must be exactly 40 hex characters): " + hash + ", skipping.");
                continue;
            }
            // Reject placeholder hashes (e.g. "000...0001") — any hash with almost
            // all zero nibbles is not a real SHA-1 and will silently break clients.
            if (countNonZeroNibbles(hash) < MIN_NONZERO_NIBBLES) {
                plugin.getLogger().warning("Pack '" + key + "' appears to have a placeholder SHA-1 hash. Replace it with your real hash, skipping.");
                continue;
            }

            Component promptComponent = Component.empty();
            if (!prompt.isEmpty()) {
                try {
                    promptComponent = MiniMessage.miniMessage().deserialize(prompt);
                } catch (Exception e) {
                    plugin.getLogger().warning("Pack '" + key + "' has an invalid MiniMessage prompt, using empty. Error: " + e.getMessage());
                }
            }

            newPacks.add(new ResourcePackEntry(key, url, hash, required, promptComponent));
            plugin.getLogger().info("Loaded pack: " + key + " -> " + url);
        }

        packs = Collections.unmodifiableList(newPacks);
        return !packs.isEmpty();
    }

    public void sendPacksToPlayer(Player player) {
        List<ResourcePackEntry> snapshot = packs;
        for (ResourcePackEntry pack : snapshot) {
            try {
                // Derive the pack UUID directly from its SHA-1 hash bytes.
                // This is deterministic (same pack always gets the same UUID across
                // restarts, so clients can cache it), unique per pack content, and
                // avoids the Type-3 / nameUUIDFromBytes approach which could collide
                // if two packs share an ID-prefix but differ only in URL.
                byte[] hashBytes = fromHex(pack.hash());
                // Use the first 8 bytes of the SHA-1 as the UUID's two long words,
                // then set variant/version bits for a valid RFC-4122 Type-4 UUID.
                long msb = bytesToLong(hashBytes, 0);
                long lsb = bytesToLong(hashBytes, 8);
                // Clear and set version (4) and variant (2) bits
                msb = (msb & 0xFFFFFFFFFFFF0FFFL) | 0x0000000000004000L;
                lsb = (lsb & 0x3FFFFFFFFFFFFFFFL) | 0x8000000000000000L;
                UUID packUUID = new UUID(msb, lsb);

                player.addResourcePack(
                        packUUID,
                        pack.url(),
                        hashBytes,
                        pack.prompt(),
                        pack.required()
                );
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to send pack '" + pack.id() + "' to "
                        + player.getName() + ": " + e.getMessage());
            }
        }
    }

    public int getSendDelayTicks() {
        return sendDelayTicks;
    }

    public List<ResourcePackEntry> getPacks() {
        return packs; // already unmodifiable
    }

    public int getPackCount() {
        return packs.size();
    }

    /**
     * Validates that a URL is absolute, uses http or https, and has a non-empty host.
     */
    private boolean isValidUrl(String url) {
        try {
            URI uri = new URI(url);
            if (!uri.isAbsolute()) return false;
            String scheme = uri.getScheme();
            if (scheme == null) return false;
            if (!scheme.equals("http") && !scheme.equals("https")) return false;
            String host = uri.getHost();
            return host != null && !host.isEmpty();
        } catch (URISyntaxException e) {
            return false;
        }
    }

    /**
     * Converts a validated 40-char hex SHA-1 string to a 20-byte array.
     */
    private byte[] fromHex(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            int high = Character.digit(hex.charAt(i), 16);
            int low  = Character.digit(hex.charAt(i + 1), 16);
            if (high == -1 || low == -1) {
                throw new IllegalStateException("Invalid hex character in hash: " + hex);
            }
            data[i / 2] = (byte) ((high << 4) + low);
        }
        return data;
    }

    /**
     * Counts the number of non-zero hex nibbles in a hash string.
     * Used to detect near-zero placeholder hashes from the default config.
     */
    private int countNonZeroNibbles(String hex) {
        int count = 0;
        for (int i = 0; i < hex.length(); i++) {
            if (hex.charAt(i) != '0') count++;
        }
        return count;
    }

    /**
     * Reads 8 bytes from {@code bytes} starting at {@code offset} as a big-endian long.
     */
    private long bytesToLong(byte[] bytes, int offset) {
        long result = 0;
        for (int i = 0; i < 8; i++) {
            result = (result << 8) | (bytes[offset + i] & 0xFF);
        }
        return result;
    }
}
