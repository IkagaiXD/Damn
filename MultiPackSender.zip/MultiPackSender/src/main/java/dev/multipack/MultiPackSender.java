package dev.multipack;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

public class MultiPackSender extends JavaPlugin {

    private PackManager packManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        packManager = new PackManager(this);

        if (!packManager.loadPacks()) {
            getLogger().severe("No valid resource packs found in config.yml! Disabling plugin.");
            // Calling disablePlugin() directly inside onEnable() can leave the plugin
            // in a broken half-registered state on Paper/Purpur. Schedule it for the
            // next tick when the enable sequence has fully completed.
            new BukkitRunnable() {
                @Override
                public void run() {
                    getServer().getPluginManager().disablePlugin(MultiPackSender.this);
                }
            }.runTask(this);
            return;
        }

        getServer().getPluginManager().registerEvents(new PackListener(this, packManager), this);

        PluginCommand cmd = getServer().getPluginCommand("multipack");
        if (cmd != null) {
            PackCommand packCommand = new PackCommand(this, packManager);
            cmd.setExecutor(packCommand);
            cmd.setTabCompleter(packCommand);
        } else {
            getLogger().warning("Could not register /multipack command — is it declared in plugin.yml?");
        }

        getLogger().info("MultiPackSender enabled. Loaded " + packManager.getPackCount() + " resource pack(s).");
    }

    @Override
    public void onDisable() {
        getLogger().info("MultiPackSender disabled.");
    }
}
