package dev.multipack;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class PackListener implements Listener {

    private final MultiPackSender plugin;
    private final PackManager packManager;

    public PackListener(MultiPackSender plugin, PackManager packManager) {
        this.plugin = plugin;
        this.packManager = packManager;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        int delayTicks = packManager.getSendDelayTicks();

        if (delayTicks <= 0) {
            // Player is guaranteed online inside PlayerJoinEvent — no isOnline() check needed
            packManager.sendPacksToPlayer(event.getPlayer());
            return;
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                // Guard: player may have disconnected during the delay,
                // or the plugin may have been disabled
                if (!plugin.isEnabled()) return;
                if (!event.getPlayer().isOnline()) return;
                packManager.sendPacksToPlayer(event.getPlayer());
            }
        }.runTaskLater(plugin, delayTicks);
    }
}
