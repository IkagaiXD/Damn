package dev.multipack;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.List;

public class PackCommand implements CommandExecutor, TabCompleter {

    private final MultiPackSender plugin;
    private final PackManager packManager;

    public PackCommand(MultiPackSender plugin, PackManager packManager) {
        this.plugin = plugin;
        this.packManager = packManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("multipack.admin")) {
            sender.sendMessage(Component.text("You don't have permission to use this command.", NamedTextColor.RED));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                // Capture the count from the return of loadPacks via getPackCount()
                // immediately after — both reads see the same freshly-written volatile,
                // but snapshot it here to avoid a second volatile read for the message.
                boolean loaded = packManager.loadPacks();
                int count = packManager.getPackCount(); // same volatile write, safe to read once
                if (loaded) {
                    sender.sendMessage(Component.text("MultiPackSender reloaded! Loaded " + count + " pack(s).", NamedTextColor.GREEN));
                } else {
                    sender.sendMessage(Component.text("Reload failed — no valid packs found. Check your config.", NamedTextColor.RED));
                }
            }
            case "resend" -> {
                if (args.length > 1) {
                    // Bug fix: console can also target a specific player by name
                    String targetName = args[1];
                    Player targetPlayer = plugin.getServer().getPlayerExact(targetName);
                    if (targetPlayer == null) {
                        sender.sendMessage(Component.text("Player '" + targetName + "' not found or is offline.", NamedTextColor.RED));
                        return true;
                    }
                    packManager.sendPacksToPlayer(targetPlayer);
                    sender.sendMessage(Component.text("Resent packs to " + targetPlayer.getName() + ".", NamedTextColor.GREEN));
                } else if (sender instanceof Player player) {
                    // No target specified, player sender — resend to self
                    packManager.sendPacksToPlayer(player);
                    sender.sendMessage(Component.text("Resent all packs to you.", NamedTextColor.GREEN));
                } else {
                    // Console with no target — resend to everyone
                    int count = 0;
                    for (Player p : plugin.getServer().getOnlinePlayers()) {
                        packManager.sendPacksToPlayer(p);
                        count++;
                    }
                    sender.sendMessage(Component.text("Resent packs to " + count + " player(s).", NamedTextColor.GREEN));
                }
            }
            case "list" -> {
                // Snapshot once — avoids a TOCTOU race where a reload fires between
                // getPacks() and getPackCount(), making the count and list disagree.
                List<ResourcePackEntry> snapshot = packManager.getPacks();
                if (snapshot.isEmpty()) {
                    sender.sendMessage(Component.text("No packs loaded.", NamedTextColor.YELLOW));
                } else {
                    sender.sendMessage(Component.text("Loaded packs (" + snapshot.size() + "):", NamedTextColor.GOLD));
                    for (ResourcePackEntry pack : snapshot) {
                        sender.sendMessage(Component.text("  \u2022 " + pack.id() + " \u2014 " + pack.url(), NamedTextColor.GRAY));
                    }
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Component.text("MultiPackSender Commands:", NamedTextColor.GOLD));
        sender.sendMessage(Component.text("  /multipack reload", NamedTextColor.YELLOW)
                .append(Component.text(" \u2014 Reload config and packs", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("  /multipack resend [player]", NamedTextColor.YELLOW)
                .append(Component.text(" \u2014 Resend packs to yourself, a player, or all (console with no arg)", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("  /multipack list", NamedTextColor.YELLOW)
                .append(Component.text(" \u2014 List loaded packs", NamedTextColor.GRAY)));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("multipack.admin")) return List.of();

        if (args.length == 1) {
            String partial = args[0].toLowerCase();
            return List.of("reload", "resend", "list").stream()
                    .filter(s -> s.startsWith(partial))
                    .toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("resend")) {
            String partial = args[1].toLowerCase();
            return plugin.getServer().getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase().startsWith(partial))
                    .toList();
        }
        return List.of();
    }
}
