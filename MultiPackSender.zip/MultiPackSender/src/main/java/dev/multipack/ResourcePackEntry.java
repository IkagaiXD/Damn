package dev.multipack;

import net.kyori.adventure.text.Component;

public record ResourcePackEntry(
        String id,
        String url,
        String hash,
        boolean required,
        Component prompt
) {}
